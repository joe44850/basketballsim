This font pack contains a bunch of NBA fonts.  Enjoy!

The numbers & letters were originally created by Nick Whitford (whitedragon22na@yahoo.com) and Dennis "LMUpepbander" Ittner.

The TTF fonts were created by Eriq P. Jaffe (eriqjaffe@hotmail.com)

Enjoy!